# npm install
# npm start